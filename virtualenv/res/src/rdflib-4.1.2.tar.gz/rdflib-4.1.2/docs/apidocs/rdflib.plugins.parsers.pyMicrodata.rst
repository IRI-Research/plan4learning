pyMicrodata Package
===================

:mod:`pyMicrodata` Package
--------------------------

.. automodule:: rdflib.plugins.parsers.pyMicrodata
    :members:
    :undoc-members:
    :show-inheritance:

:mod:`microdata` Module
-----------------------

.. automodule:: rdflib.plugins.parsers.pyMicrodata.microdata
    :members:
    :undoc-members:
    :show-inheritance:

:mod:`registry` Module
----------------------

.. automodule:: rdflib.plugins.parsers.pyMicrodata.registry
    :members:
    :undoc-members:
    :show-inheritance:

:mod:`utils` Module
-------------------

.. automodule:: rdflib.plugins.parsers.pyMicrodata.utils
    :members:
    :undoc-members:
    :show-inheritance:

