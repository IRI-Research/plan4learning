.. _contrib-modules:

Contrib Modules
===============

These modules implement various extra features, that may not be ready for
prime time.

.. _pyopenssl:

SNI-support for Python 2
------------------------

.. automodule:: urllib3.contrib.pyopenssl
