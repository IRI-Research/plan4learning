extras Package
==============

:mod:`extras` Package
---------------------

.. automodule:: rdflib.plugins.parsers.pyRdfa.extras
    :members:
    :undoc-members:
    :show-inheritance:

:mod:`httpheader` Module
------------------------

.. automodule:: rdflib.plugins.parsers.pyRdfa.extras.httpheader
    :members:
    :undoc-members:
    :show-inheritance:
    :exclude-members: __dict__,__weakref__
