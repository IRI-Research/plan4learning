======================
Contributing to Django
======================

As an open source project, Django welcomes contributions of many forms.

Examples of contributions include:

* Code patches
* Documentation improvements
* Bug reports and patch reviews

Extensive contribution guidelines are available in the repository at
``docs/internals/contributing/``, or online at:

https://docs.djangoproject.com/en/dev/internals/contributing/
