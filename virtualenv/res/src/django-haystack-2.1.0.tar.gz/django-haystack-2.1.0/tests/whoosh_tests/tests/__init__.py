import warnings
warnings.simplefilter('ignore', Warning)

from whoosh_tests.tests.forms import *
from whoosh_tests.tests.inputs import *
from whoosh_tests.tests.whoosh_query import *
from whoosh_tests.tests.whoosh_backend import *
