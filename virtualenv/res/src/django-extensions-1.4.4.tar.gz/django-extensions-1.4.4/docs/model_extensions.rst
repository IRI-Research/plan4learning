Model extensions
================

:synopsis: Current Model Extensions


Current Database Model Extensions
---------------------------------

* *TimeStampedModel* - TimeStampedModel An abstract base class model that
  provides self-managed "created" and "modified" fields.