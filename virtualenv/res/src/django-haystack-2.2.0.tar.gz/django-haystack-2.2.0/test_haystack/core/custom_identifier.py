
def get_identifier_method(key):
    """
    Custom get_identifier method used for testing the
    setting HAYSTACK_IDENTIFIER_MODULE
    """
    return key
