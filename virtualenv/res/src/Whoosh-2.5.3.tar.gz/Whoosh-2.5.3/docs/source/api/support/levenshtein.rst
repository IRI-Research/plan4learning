==============================
``support.levenshtein`` module
==============================

.. automodule:: whoosh.support.levenshtein

.. autofunction:: relative

.. autofunction:: distance

